<?php require_once("database.php") ?>
<!DOCTYPE html>
<html>
<head>
	<title>Exam page</title>
</head>
<body>
	<?php include_once("nav_bar.php") ?>
	<?php get_questions(); ?>
</body>
</html>