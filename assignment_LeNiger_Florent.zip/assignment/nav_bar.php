<div id="menu">
	<ul>
		<li><a href="reset_database.php">Reset database</a></li>
		<li><a href="insert_question.php">Insert questions</a></li>
		<li><a href="exam_page.php">Exam</a></li>
	</ul>
</div>