<!DOCTYPE html>
<html>
<head>
	<title>Index</title>
</head>
<body>
	<?php include_once("nav_bar.php") ?>
</body>
</html>